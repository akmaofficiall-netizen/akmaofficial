import { NextResponse } from "next/server";
import {
  getDashboardKPIs,
  getSalesReport,
  getFinancialProfitReport,
  getCashFlowReport,
  getInventoryAndRawMaterialReport,
  getProjectComparisonReport
} from "@/services/reporting";
import { simulateInflationImpact } from "@/services/pricing";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type") || "dashboard";
    const projectId = searchParams.get("projectId");
    const startDateStr = searchParams.get("startDate");
    const endDateStr = searchParams.get("endDate");
    const customerId = searchParams.get("customerId");
    const employeeId = searchParams.get("employeeId");

    const filter = {
      projectId: projectId || null,
      startDate: startDateStr ? new Date(startDateStr) : null,
      endDate: endDateStr ? new Date(endDateStr) : null,
      customerId: customerId || null,
      employeeId: employeeId || null,
    };

    if (type === "dashboard") {
      const data = await getDashboardKPIs(filter);
      return NextResponse.json({ success: true, data });
    }

    if (type === "sales") {
      const data = await getSalesReport(filter);
      return NextResponse.json({ success: true, data });
    }

    if (type === "financial") {
      const data = await getFinancialProfitReport(filter);
      return NextResponse.json({ success: true, data });
    }

    if (type === "cashflow") {
      const data = await getCashFlowReport(filter);
      return NextResponse.json({ success: true, data });
    }

    if (type === "inventory") {
      const data = await getInventoryAndRawMaterialReport(filter);
      return NextResponse.json({ success: true, data });
    }

    if (type === "project_comparison") {
      const projA = searchParams.get("projectAId");
      const projB = searchParams.get("projectBId");
      if (!projA || !projB) {
        return NextResponse.json({ success: false, error: "انتخاب دو پروژه برای مقایسه الزامی است." }, { status: 400 });
      }
      const data = await getProjectComparisonReport(projA, projB);
      return NextResponse.json({ success: true, data });
    }

    return NextResponse.json({ success: false, error: "نوع گزارش نامعتبر است." }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    if (body.action === "simulate_inflation") {
      const simulation = await simulateInflationImpact(body.changes || {});
      return NextResponse.json({ success: true, simulation });
    }

    return NextResponse.json({ success: false, error: "عملیات نامعتبر" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
